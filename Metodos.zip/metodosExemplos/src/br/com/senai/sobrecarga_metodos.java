package br.com.senai;

public class sobrecarga_metodos {

	public static void main(String[] args) {
		// SOBRECARGA DE METODOS
		System.out.println("�rea do quadrado: " + area(2));
		System.out.println("�rea do ret�ngulo: " + area(2, 3));
		System.out.println("�rea do cubo: " + area(2, 5, 7));

	}

	public static double area(int x) {
		return (x * x); // MET�DO QUE CALCULA O x VEZES O x
		// EXEMPLO 2 * 2 = 4
	}

	public static double area(int x, int y) {
		return (x * y); // MET�DO QUE CALCULA O x VEZES O y
						// EXEMPLO 2 * 3 = 6
	}

	public static double area(int x, int y, int z) {
		return (x * y * z); // M�TODO QUE CALCULA O x VEZES O y E VEZES O Z
		// EXEMPLO 2 * 5 * 7 = 70
	}
}
