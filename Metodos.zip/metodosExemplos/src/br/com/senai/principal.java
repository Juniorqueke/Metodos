package br.com.senai;

public class principal {

	public static void main(String[] args) {
		// METODOS SEM RETORNO
		imprimir(); // CHAMANDO O M�TODO CRIADO
		imprimirTexto("Tricks or treats?");
		somar(8, 5);
		quadrado(10, 3);
		maiorNumero(13, 31, 666);
		sexo('F');
	}

	public static void imprimir() { // FUN��O QUE IMPRIME A MENSAGEM ABAIXO NA TELA
		System.out.println("Aprendendo a linguagem java!");
	}

	public static void imprimirTexto(String texto) {
		System.out.println(texto); // FUN��O QUE IMPRIME NA TELA O QUE O USU�RIO ENVIA

	}

	public static void somar(int a, int b) {
		System.out.println(a + b); // FUN��O QUE SOMA DOIS VALORES DO TIPO INTEIRO
	}

	public static void quadrado(int a, int b) {
		System.out.println(Math.pow(a, b)); // FUN��O QUE C�LCULA A POT�NCIA ELEVADO AO CUBO
	}

	public static void maiorNumero(int x, int y, int z) {
		System.out.println(Math.max(Math.max(x, y), z)); // PRIMEIRO � COMPARADO OS VALORES DE x E y
		// DEPOIS SALVA O VALOR MAIOR E COMPARA COM O VALOR DE z E COMPARA OS DOIS
	}

	public static void sexo(char c) { // PARA SABER QUAL � O SEXO DO USU�RIO
		if (c == 'F') { 
			System.out.println("Feminino");
		} else if (c == 'M') {
			System.out.print("Masculino");
		} else {
			System.out.println("Sexo desconhecido");
		}
	}
}